const movies=[
 {id:1,title:"Midnight Chase",lang:"English",genre:"Action • Thriller",rating:"8.6",cls:"m1"},
 {id:2,title:"Ocean Dreams",lang:"Telugu",genre:"Drama • Romance",rating:"8.1",cls:"m2"},
 {id:3,title:"Final Mission",lang:"Hindi",genre:"Action • Adventure",rating:"8.4",cls:"m3"},
 {id:4,title:"Golden Hearts",lang:"Tamil",genre:"Family • Drama",rating:"7.9",cls:"m4"}
];
let selectedMovie=null,selectedTime=null,selectedSeats=[];

function renderMovies(){
 const q=document.getElementById("search").value.toLowerCase();
 document.getElementById("movieGrid").innerHTML=movies.filter(m=>m.title.toLowerCase().includes(q)).map(m=>`
 <article class="movie">
   <div class="poster ${m.cls}">${m.title}</div>
   <div class="movie-info"><h3>${m.title}</h3><p>${m.genre}</p><p>⭐ ${m.rating} • ${m.lang}</p>
   <button class="book" onclick="openBooking(${m.id})">Book Tickets</button></div>
 </article>`).join("");
}
function openBooking(id){
 selectedMovie=movies.find(m=>m.id===id); selectedSeats=[]; selectedTime=null;
 document.getElementById("modal").classList.remove("hidden");
 document.getElementById("bookingStep").innerHTML=`
 <h2 class="step-title">${selectedMovie.title}</h2><p>${selectedMovie.genre} • ⭐ ${selectedMovie.rating}</p>
 <h3>1. Select Theatre</h3><select id="theatre" style="padding:12px;width:100%;border:1px solid #ddd;border-radius:7px">
 <option>INOX - GVK One Mall</option><option>PVR Cinemas - Forum Mall</option><option>Cinepolis - Central Mall</option></select>
 <h3>2. Select Show Time</h3><div class="showtimes">${["10:30 AM","1:45 PM","4:30 PM","7:30 PM","10:15 PM"].map(t=>`<button onclick="selectTime(this,'${t}')">${t}</button>`).join("")}</div>
 <div id="nextArea" style="margin-top:20px"></div>`;
}
function selectTime(btn,time){
 selectedTime=time;
 document.querySelectorAll(".showtimes button").forEach(b=>b.style.background="white");
 btn.style.background="#ffe3ed";
 document.getElementById("nextArea").innerHTML='<button class="book" onclick="showSeats()">Continue to Seats</button>';
}
function showSeats(){
 document.getElementById("bookingStep").innerHTML=`
 <h2>Select Your Seats</h2><p>${selectedMovie.title} • ${selectedTime}</p>
 <div class="seat-screen"></div><div style="text-align:center;color:#888;font-size:12px">SCREEN THIS WAY</div>
 <div class="seats">${Array.from({length:40},(_,i)=>{let n=i+1,occupied=[4,9,17,26,33].includes(n);return `<button class="seat ${occupied?"occupied":""}" ${occupied?"disabled":""} onclick="toggleSeat(this,${n})">${n}</button>`}).join("")}</div>
 <div class="summary"><b>Selected:</b> <span id="selectedText">None</span><br><b>Total:</b> ₹<span id="total">0</span></div>
 <button class="pay" onclick="checkout()">Continue to Checkout</button>`;
}
function toggleSeat(btn,n){
 if(btn.classList.contains("selected")){btn.classList.remove("selected");selectedSeats=selectedSeats.filter(x=>x!==n)}
 else {if(selectedSeats.length>=6){alert("Maximum 6 seats per booking.");return}btn.classList.add("selected");selectedSeats.push(n)}
 document.getElementById("selectedText").textContent=selectedSeats.length?selectedSeats.join(", "):"None";
 document.getElementById("total").textContent=selectedSeats.length*180;
}
function checkout(){
 if(!selectedSeats.length){alert("Please select at least one seat.");return}
 document.getElementById("bookingStep").innerHTML=`
 <h2>Checkout</h2><p>Review your booking before payment.</p>
 <div class="summary"><b>${selectedMovie.title}</b><br>INOX - GVK One Mall<br>${selectedTime}<br>Seats: ${selectedSeats.join(", ")}<hr>
 Tickets: ₹${selectedSeats.length*180}<br>Convenience fee: ₹${selectedSeats.length*20}<br><b>Total: ₹${selectedSeats.length*200}</b></div>
 <input id="name" placeholder="Full name" style="width:100%;padding:13px;margin-top:15px;border:1px solid #ddd;border-radius:7px">
 <button class="pay" onclick="confirmBooking()">Pay ₹${selectedSeats.length*200}</button>`;
}
function confirmBooking(){
 let name=document.getElementById("name").value.trim()||"MovieHub User";
 let id="MH"+Math.floor(100000+Math.random()*900000);
 localStorage.setItem("lastBooking",JSON.stringify({id,name,movie:selectedMovie.title,time:selectedTime,seats:selectedSeats}));
 document.getElementById("bookingStep").innerHTML=`
 <div class="success"><div class="success-icon">🎉</div><h2>Booking Confirmed!</h2><p>Your movie ticket has been booked successfully.</p>
 <div class="ticket"><b>Booking ID:</b> ${id}<br><b>Name:</b> ${name}<br><b>Movie:</b> ${selectedMovie.title}<br><b>Show:</b> ${selectedTime}<br><b>Seats:</b> ${selectedSeats.join(", ")}<br><b>Total:</b> ₹${selectedSeats.length*200}</div>
 <button class="book" onclick="closeModal()">Done</button></div>`;
 setTimeout(closeModal,5000);
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
renderMovies();